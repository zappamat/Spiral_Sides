export const COLORS = {
  primary: '#00684A',
};
